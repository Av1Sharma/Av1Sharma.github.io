import os ## need computer access
import face_recognition ## see step 1
import cv2 ## also step 1
import shutil ## to create folder of sorted photos

## Since my folder is nearly 50Gbs big, I will not create a folder called unsorted photos. I will merely point the script to the folder

REFERENCE_FOLDER = "/Users/avi/Desktop/ReferencePhotos"
TARGET_FOLDER = "/Users/avi/Desktop/RoboticsPhotos"
OUTPUT_FOLDER = "/Users/avi/Desktop/SortedPhotos"

# Dictionaries to store our known face data
known_faces = {}

VALID_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")  # This fixes it!

print("Loading reference photos...")

for filename in os.listdir(REFERENCE_FOLDER):
    if filename.lower().endswith(VALID_EXTENSIONS):
        # 1. Get the base name (e.g., "Avi1" or "Avi_2")
        base_name = os.path.splitext(filename)[0]
        
        # 2. Strip out any numbers or underscores so "Avi1" or "Avi_1" just becomes "Avi"
        name = ''.join([i for i in base_name if i.isalpha()]).strip()
            
        img_path = os.path.join(REFERENCE_FOLDER, filename)
        try:
            ref_image = face_recognition.load_image_file(img_path)
            ref_encoding = face_recognition.face_encodings(ref_image)[0]
            
            # Append the encoding and the cleaned name
            if name not in known_faces:
                known_faces[name] = [ref_encoding]
            else:
                known_faces[name].append(ref_encoding)
            print(f"-> Learned a face profile for: {name}")
        except IndexError:
            print(f"!! No face found in reference file: {filename}")

# Let's count UNIQUE names using a Python 'set'
unique_people = len(set(known_face_names))
print(f"\nFinished loading references. Total unique people known: {unique_people}\n")

print("Starting 50GB scan across all subfolders...")

# 1. os.walk goes deep into your subfolders (2024, 2025, etc.)
for root, dirs, files in os.walk(TARGET_FOLDER):
    for filename in files:
        # Skip files that aren't images
        if not filename.lower().endswith(VALID_EXTENSIONS):
            continue
            
        # FIX: Use 'root' instead of TARGET_FOLDER so Python finds files deep inside subfolders
        file_path = os.path.join(root, filename)
        print(f"\nProcessing {filename}...")

        # FIX: Everything below is now properly indented inside the loop!
        try:
            # 2. Load the image from the 50GB library
            image = face_recognition.load_image_file(file_path)
            
            # 3. Find where the faces are, then calculate their math encodings
            face_locations = face_recognition.face_locations(image, model="hog")
            face_encodings = face_recognition.face_encodings(image, face_locations)
            
            print(f"-> Found {len(face_locations)} face(s) in this photo.")
            
            # 4. Loop through every single face found in this specific photo
            for mystery_face_encoding in face_encodings:
                
                # Compare the mystery face against all known reference photos
                matches = face_recognition.compare_faces(known_face_encodings, mystery_face_encoding, tolerance=0.6)
                
                # Check if a match was identified
                for index in range(len(matches)):
                    if matches[index]:
                        name = known_face_names[index]
                        print(f" MATCH FOUND: {name} is in {filename}!")
                        
                        # Create a path for this specific person's sorted folder
                        person_output_dir = os.path.join(OUTPUT_FOLDER, name)
                        
                        # Automatically create the folder if it does not exist yet
                        os.makedirs(person_output_dir, exist_ok=True)
                        
                        # Define the final destination path for the copied file
                        destination_path = os.path.join(person_output_dir, filename)
                        
                        # Copy the file if it hasn't been copied yet
                        if not os.path.exists(destination_path):
                            shutil.copy(file_path, destination_path)
                            print(f"    Copied {filename} to SortedPhotos/{name}/")
                        
        except Exception as e:
            print(f"-> Could not process {filename}. Error: {e}")

print("\nScan complete!")